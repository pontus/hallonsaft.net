/*
 * Evil nump reader v 0.5 by Pontus Sk�ld
 */

#include <sys/io.h> 
#include <unistd.h>
#include <stdio.h>
#include <errno.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <syslog.h>
#include <locale.h>

#include "boolean.h"

#define DEFAULT_PORT 0x378;
#define BUF_SIZE 1024 
#define VERSION "0.4"

/* 
 * Gain access to port.
 */

int get_access_to_port(int port)
{
  if( ioperm(port,2,1) )
    {
      perror("ioperm failure");
      return -1;
    }

  if( -1 == nice(-19) )
    {
      perror("nice failure");
      return -1;
    }

  return 0;
}




int read_from_port(int port)
{
  /*
   *             0   1   2   3   4   5   6   7   8
   */
  char table[]={'4','5','6','7','#','D','B','C','A',
		/*
		 *   9   a   b   c   d   e   f
		 */
		
		    '1','2','3','8','9','0','*'
  };

  static int lastvalue;
  int value;
  int rval=-1;

  value=inb(port);

  if( ( lastvalue & 8) != (value & 8) && (value & 8) )
      rval=table[ (value >> 4) & 0xf ];

  lastvalue=value;
  usleep(1990);
  
  return rval;
}





void write_call_info( FILE* outfile, char* callstring)
{
  time_t time_now;
  char* txtp=callstring;

  time( &time_now );

  while( *txtp !='C' )
    {
      if( 'A' == *txtp)
	{
	  fprintf(outfile, "Call from ");
	  txtp++;
	}
      else if ( 'B' == *txtp )
	{
	  char* old_txtp=txtp++;

	  fprintf(outfile, "Information code: ");
	  
	  while( *txtp != 'C' )
	    fprintf(outfile, "%c", *txtp++);

	  if( 0 == strcmp( "B00C", old_txtp ) )
	    fprintf(outfile, " (no number transferred)");
	  else if ( 0 == strcmp( "B10C", old_txtp ) )
	    fprintf(outfile, " (secret number) ");

	}
      else if ( 'D' == *txtp)
	{
	  fprintf(outfile, " diverted from ");
	  txtp++;
	}

      else if ( 0 == *txtp )
	{
	  fprintf(outfile, " << Error: callstring incorrectly terminated >>");
	  break;
	}
      else
	{
	  fprintf( outfile, "%c", *txtp++);
	}
    }

  fprintf(outfile, " at %s",
	  ctime( &time_now )
	  );
  
  fflush(outfile);
}





/* 3bc, 378, 278 */

int main(const int argv, const char** args)
{

  int my_port;
  bool sysl=true;
  bool badArgs=false;
  FILE* outfile=stdout;
  char** argp=(char**) args;

  if( 0 != fork() )
    {
      exit(0);
    }


  my_port=DEFAULT_PORT; /* Port number, MAX 0x3ff (1024) */
  argp++;

  
  while( *argp != NULL )
    {
      char* cur_arg=*argp;
      argp++;
      
      /* 
       * printf("Arg: %s\n", cur_arg);
       */

      fflush(stdout);
      
      /*
       * Let them specify the port to use with the switch -p or --port
       */

      if( 0 == strcmp("-p", cur_arg) || 0 == strcmp("--port", cur_arg) )
	{
	  printf("Setting port... \n");
	  sscanf( *argp, "%i", &my_port);
	  argp++;
	}

      /*
       * If we know what version we are, offer the options -v and --version.
       */

#ifdef VERSION
      else if ( 0 == strcmp("-v", cur_arg) || 0==strcmp("--version", cur_arg) )
	{
	  fprintf( stdout, 
		   "nump v %s by Pontus Freyhult,"
		   "pont_numb@soua.net\n",
		   VERSION
		   );
	}
#endif

      /*
       *  Output file
       */

      else if ( 0 == strcmp("-o", cur_arg) || 0==strcmp("--output", cur_arg) )
	{
	  if( 0 != strcmp("-", *argp) )     /* - means stdout */
	      outfile=fopen( *argp, "w");
	  argp++;
	}

      /*
       *  Append file
       */
      
      else if ( 0 == strcmp("-a", cur_arg) || 0==strcmp("--append", cur_arg) )
        {
          if( 0 != strcmp("-", *argp) )     /* - means stdout */
	    outfile=fopen( *argp, "a");
          argp++;
        }
      

      
      /*
       * Or a bad argument 
       */

      else
        {
          printf("Bad Argument: %s \n", cur_arg);
          badArgs = true;
        }
      

    }


  
  if ( badArgs )
    {
      fprintf(stdout,
	      "usage: %s [ options ]...]\n"
	      "where options are:\n"
	      "-p PORT or --port PORT: uses PORT for base address\n"
	      "-v or --version for the current version of nump\n"
	      "-h or --help for this message\n"
	      "-o FILENAME or --output FILENAME to overwrite FILENAME\n"
	      "-a FILENAME or --append FILENAME to append to FILENAME\n"
	      "-s or --syslog to make syslog entries \n",
	      args[0]
	      );

      return -1;
    }
  
  
  /* 
   * If syslog entries are requested, we open it now
   */
  
  if( sysl )
    openlog( "nump", LOG_DAEMON , LOG_CONS | LOG_PID | LOG_NDELAY );
  

  
  /*
   *
   */
  
  if( get_access_to_port(my_port) )
    {
      fprintf( stderr, "Sorry, could not open port $%x \n", my_port);
      
      if( sysl )
	syslog( LOG_ERR, 
		"nump couldn't access port $%x, quitting",
		my_port
		);

      return -1;
    }



  /*    write_call_info( stdout, "A00dsf" );
   */ 
  
  while( true )
    {
    char call_string[ BUF_SIZE ];
    int counter=0;
    int i=0;
    char this_step=0;
    int no_tone_counter=0;

    for( ; i < BUF_SIZE ; )
      call_string[i++]=0;

    while( no_tone_counter < 100 )
      {
	this_step=read_from_port( my_port+1 );

	if( -1 != this_step )	
	  {
	    call_string[counter++] = this_step;

	    no_tone_counter=0;
	  }
	else
	  no_tone_counter++;
      }
    
    if( counter > 0)
      {
	write_call_info( outfile, call_string);
	
	if ( sysl )
	  {
	    syslog( LOG_NOTICE, "Callstring: %s", call_string );
	  }

      }
  }

  return 0;

}
