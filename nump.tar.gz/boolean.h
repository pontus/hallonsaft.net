#ifndef __BOOLEAN_H__
#define __BOOLEAN_H__

typedef int boolean;
typedef int bool;

#define true 1==1
#define false 0==1

#endif
